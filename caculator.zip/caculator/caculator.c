#include <stdio.h>

int main(void)
{
	int num1, num2, dummy;
	printf("첫번째 수를 입력하세요. : ");
	scanf("%d", &num1);
	printf("두번째 수를 입력하세요. : ");
	scanf("%d", &num2);
	printf("%d + %d = %d", num1, num2, num1 + num2);
	scanf("%d", dummy);
	return 0;

}

