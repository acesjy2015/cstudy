#include <stdio.h>

int main(void) {
	char ch1='H';
	char ch2='e';
	char ch3='l';
	char ch4='l';
	char ch5='o';
	char dummy;
	
	printf("%c   %c   %c   %c   %c\n", ch1, ch2, ch3, ch4, ch5);
	printf("%d %d %d %d %d", ch1, ch2, ch3, ch4, ch5);
	
	scanf("%c", &dummy);
	return 0;
}
